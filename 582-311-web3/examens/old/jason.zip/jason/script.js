gsap.registerPlugin(ScrollTrigger);

// 1. Ajouter une boucle "for" pour créer 100 coulisses de sang (span dans le div .sang)

// 2. Ces coulisses doivent être animées en une durée aléatoire

// 3. L'animation doit se déclencher avec un scrollTrigger
