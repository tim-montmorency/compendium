<template>
  <main class="container">
    <h1>Mini-catalogue — Jeux retro</h1>

    <!-- Controles dans le parent App.vue (version sans emits) -->
    <section class="controls">
      <label>
        Trier par :
        <select v-model="sortBy">
          <option value="title">Titre</option>
          <option value="price">Prix</option>
          <option value="year">Annee</option>
        </select>
      </label>

      <label>
        Ordre :
        <select v-model="sortDir">
          <option value="asc">Ascendant</option>
          <option value="desc">Descendant</option>
        </select>
      </label>

      <label>
        Limite :
        <input type="number" min="1" :max="items.length" v-model.number="limit" />
      </label>

      <fieldset class="layout">
        <legend>Disposition</legend>
        <label><input type="radio" value="grid" v-model="layout" /> Grille</label>
        <label><input type="radio" value="list" v-model="layout" /> Liste</label>
      </fieldset>
    </section>

    <!-- Affichage des jeux -->
    
    <ItemList
      :items="itemsFiltered"
      :layout="layout"
    />
  </main>
</template>

<script>
import ItemList from './components/ItemList.vue'
import OptionsBar from './components/OptionsBar.vue'

export default {
  name: 'App',
  components: { ItemList, OptionsBar },
  data() {
    return {
      // TODO: vous pouvez ajouter/modifier des jeux
      items: [
        { id: 1, title: 'NES - Super Mario Bros.', price: 24.99, year: 1985, image: new URL('./assets/nes_mario.png', import.meta.url).href, tags: ['plateformer','classic'] },
        { id: 2, title: 'SNES - The Legend of Zelda: A Link to the Past', price: 39.99, year: 1991, image: new URL('./assets/snes_zelda.png', import.meta.url).href, tags: ['action','aventure'] },
        { id: 3, title: 'Game Boy - Tetris', price: 14.99, year: 1989, image: new URL('./assets/gb_tetris.png', import.meta.url).href, tags: ['puzzle','classique'] },
        { id: 4, title: 'Genesis - Sonic the Hedgehog', price: 19.99, year: 1991, image: new URL('./assets/genesis_sonic.png', import.meta.url).href, tags: ['vitesse','plateformer'] },
        { id: 5, title: 'N64 - GoldenEye 007', price: 29.99, year: 1997, image: new URL('./assets/n64_goldeneye.png', import.meta.url).href, tags: ['fps','multijoueur'] },
        { id: 6, title: 'Arcade - Pac-Man', price: 12.99, year: 1980, image: new URL('./assets/arcade_pacman.png', import.meta.url).href, tags: ['arcade','maze'] }
      ],
      sortBy: 'title',
      sortDir: 'asc',
      limit: 6,
      layout: 'grid'
    }
  },
  computed: {
    itemsFiltered() {
      // 1) copie l'array original des items dans une constante afin de ne pas altérer l'array original
      const list = [...this.items]

      // 2) tri générique selon la clé choisie (par année, par titre ou par prix)
      list.sort((a,b) => {
        const key = this.sortBy
        const va = a[key]
        const vb = b[key]
        if (typeof va === 'string' && typeof vb === 'string') {
          return this.sortDir === 'asc' ? va.localeCompare(vb) : vb.localeCompare(va)
        }
        return this.sortDir === 'asc' ? (va - vb) : (vb - va)
      })

      // 3) limite du nombre d'item à afficher
      const limited = list.slice(0, Math.max(1, this.limit || 1))
      return limited
    }
  }
}
</script>

<style scoped>
.container {
  max-width: 1000px;
  margin: 0 auto;
  padding: 2rem 1rem 4rem;
  font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
}
h1 {
  font-size: 1.75rem;
  margin-bottom: 1rem;
}
.controls {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 0.75rem;
  margin-bottom: 1rem;
  align-items: end;
}
.controls label {
  display: grid;
  gap: 0.25rem;
  font-size: 0.95rem;
}
.controls fieldset label {
  display: inline;
}
fieldset.layout {
  border: 1px solid #ddd;
  padding: 0.5rem 0.75rem;
  border-radius: 0.5rem;
}
input[type="radio"] {
  width: auto;
}
.layout{
    display: flex;
    justify-content: space-between;
}
</style>
