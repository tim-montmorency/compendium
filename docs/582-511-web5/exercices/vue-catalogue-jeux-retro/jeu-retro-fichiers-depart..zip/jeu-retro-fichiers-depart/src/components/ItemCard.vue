<template>
  <article class="card">
    <img class="thumb" :src="image" :alt="title" />
    <div class="content">
      <header>
        <h3></h3>
        <small class="year"></small>
      </header>
      <p class="price"></p>
      <ul class="tags">
        <li>#</li>
      </ul>
    </div>
  </article>
</template>

<script>
export default {
  name: 'ItemCard',
  props: {
  
  },
  methods: {
    formatPrice(value) {
      try {
        return new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'CAD' }).format(value ?? 0)
      } catch(e) {
        return value
      }
    }
  }
}
</script>

<style scoped>
.card {
  display: grid;
  grid-template-rows: 140px auto;
  background: #fff;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 1px 2px rgba(0,0,0,0.04);
}
.thumb {
  width: 100%;
  height: 140px;
  object-fit: cover;
  background: #f3f4f6;
}
.content {
  padding: 0.75rem 0.9rem 1rem;
  display: grid;
  gap: 0.35rem;
}
header {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  gap: 0.5rem;
}
h3 {
  font-size: 1rem;
  line-height: 1.2;
}
.year {
  opacity: 0.7;
}
.price {
  font-weight: 600;
  margin-top: 0.15rem;
}
.tags {
  display: flex;
  flex-wrap: wrap;
  gap: 0.4rem;
  margin-top: 0.25rem;
  list-style: none;
}
.tags li {
  font-size: 0.8rem;
  background: #f3f4f6;
  border: 1px solid #e5e7eb;
  padding: 0.2rem 0.5rem;
  border-radius: 999px;
  list-style: none;
}
</style>
