<template>

</template>

<script>

export default {
    name: 'OptionsBar',
}

</script>

<style scoped>

</style>
