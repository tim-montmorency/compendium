<template>
   <section class="collection">
    <!-- Affichage des cartes de chaque jeu -->

    



    <p v-if="!items || items.length === 0" class="empty">Aucun item a afficher.</p>
  </section>
</template>

<script>
import ItemCard from './ItemCard.vue'

export default {
  name: 'ItemList',
  components: { ItemCard },
  props: {
   
  }
}
</script>

<style scoped>
.collection.grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 1rem;
}
.collection.list {
  display: grid;
  gap: 0.75rem;
}
.empty {
  grid-column: 1 / -1;
  opacity: 0.7;
  padding: 1rem;
}
</style>
