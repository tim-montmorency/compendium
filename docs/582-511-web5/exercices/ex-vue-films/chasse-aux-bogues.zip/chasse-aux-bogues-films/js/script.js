const app = Vue.createApp({
  data() {
    return {
      year: "2022",
      movies: [
        { title: "Parasite", year: 2019, viewed: true },
        { title: "Joker", year: 2019, viewed: true },
        { title: "La déesse des mouches à feu", year: 2020, viewed: false },
        { title: "The Power of the Dog", year: 2021, viewed: false },
        { title: "Don't Look Up", year: 2021, viewed: false },
        { title: "Ligne de fuite", year: 2022, viewed: false },
        { title: "Guillermo del Toro's Pinocchio", year: 2022, viewed: true },
        { title: "Simple comme Sylvain", year: 2023, viewed: false },
        { title: "Le plongeur", year: 2023, viewed: false },
        { title: "Dune: Part Two", year: 2024, viewed: true },
        { title: "The Substance", year: 2024, viewed: false },
        { title: "Perfect Days", year: 2024, viewed: false },
      ],
    };
  },

  methods: {
    previousYear() {
      this.year--;
    },

    nextYear() {
      year++;
    },
  },
});

app.mount("app");
