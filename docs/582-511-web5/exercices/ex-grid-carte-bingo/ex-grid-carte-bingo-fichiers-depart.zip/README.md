# Exercice 2 — Carte de bingo (5×5)

**Objectif :** créer une grille 5 colonnes × 5 rangées avec un `gap`. La cellule centrale doit afficher **★** (déjà placée dans le HTML).

## Tâches
- [ ] 1. Sur `.bingo`, activez la grille.
- [ ] 2. Définissez **5 colonnes** et **5 rangées** égales.
- [ ] 3. Ajoutez un espace de `6px` entre chaque rangée et colonne.
