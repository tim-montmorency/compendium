// Exercice 1
console.log("EXERCICE 1:\n==========\n");

// Exercice 2
console.log("EXERCICE 2:\n==========\n");

// Exercice 3
console.log("EXERCICE 3:\n==========\n");

// Exercice 4
console.log("EXERCICE 4:\n==========\n");



