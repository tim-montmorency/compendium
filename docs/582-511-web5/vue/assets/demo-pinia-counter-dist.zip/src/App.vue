<script setup></script>

<template>
    <ComponentA/>
    <ComponentB/>
</template>

<style scoped></style>
