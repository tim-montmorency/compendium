<template>
    <div class="component">
        <h1>Component B</h1>
        <p>{{ counterStore.counter }}</p>
    </div>
</template>

<script>
import { useCounterStore } from '../stores/counter'
import { mapStores } from 'pinia'

export default {
    computed: {
        ...mapStores(useCounterStore),
    }
}
</script>