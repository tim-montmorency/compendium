<template>
    <div class="component">
        <h1>Component A</h1>
        <button @click="counterStore.increment()">Ajouter</button>
    </div>
</template>

<script>
import { useCounterStore } from '../stores/counter'
import { mapStores } from 'pinia'

export default {
    computed: {
        ...mapStores(useCounterStore),
    }
}
</script>