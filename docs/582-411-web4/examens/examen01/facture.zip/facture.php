<?php

$facture = [
    "🥛 2 litres de lait 2%" =>  4.51,
    "🍁 Sirop d'érable" => 6.99,
    "🌾 2.5kg de farine non-blanchie" => 5.99,
    "🥚 12 gros œufs blancs" => 4.09
];

?>

<!doctype html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>La facture MOMO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        body {
            background: url("./facture.webp") no-repeat scroll top center #e1e0dc;
            font-family: monospace;
            color: black;
            font-size: 16px;
        }

        .facture {
            background: url("./timmomo.png") no-repeat scroll 0 0 transparent;
            width: 22rem;
            margin-top: 10rem;
            padding-top: 6rem;
        }
    </style> 
  </head>
  <body>
    <div class="container">
        <div class="row">
            <div class="col d-flex justify-content-center text-black">

                <div class="facture">
                    
                <!-- Détail de la facture ici -->
            
                </div>

            </div>
        </div>
    </div>
  </body>
</html>