// 1. Déclencher l'animation timeline au clic

// 2. Animer la goutte

// 3. Animer le liquide

// 4. Animer le colorant

// 5. Animer le liquide

// 6. Animer le parapluie

// 7. Animer le bleuet

// 8. Animer le « C´est prêt ! »
