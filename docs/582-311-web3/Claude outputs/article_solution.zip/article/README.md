# Démarrage

```sh
npm install   # une seule fois, après le clonage
npx vite      # lance le serveur (Ctrl+C pour arrêter)
```
